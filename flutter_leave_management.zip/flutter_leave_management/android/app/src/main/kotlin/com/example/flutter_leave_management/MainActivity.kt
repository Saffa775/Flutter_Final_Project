package com.example.flutter_leave_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
