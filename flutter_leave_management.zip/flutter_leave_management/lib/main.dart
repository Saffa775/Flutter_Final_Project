import 'dart:convert';
import 'package:flutter/material.dart';

void main() {
  runApp(LeaveManagementApp());
}

class LeaveManagementApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Leave Management',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LeaveManagementScreen(),
    );
  }
}

class LeaveManagementScreen extends StatefulWidget {
  @override
  _LeaveManagementScreenState createState() => _LeaveManagementScreenState();
}

class _LeaveManagementScreenState extends State<LeaveManagementScreen> {
  List<LeaveRequest> leaveRequests = [];

  @override
  void initState() {
    super.initState();
    _loadLeaveRequests();
  }

  Future<void> _loadLeaveRequests() async {
    // You can load leave requests from any other storage or API here
  }

  Future<void> _saveLeaveRequests() async {
    // You can save leave requests to any other storage or API here
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Leave Management'),
        actions: [
          IconButton(
            icon: Icon(Icons.filter_list),
            onPressed: () {
              // Implement filtering options
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: leaveRequests.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(leaveRequests[index].employeeName),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('From: ${leaveRequests[index].startDate.toString()}'),
                Text('To: ${leaveRequests[index].endDate.toString()}'),
                Text('Reason: ${leaveRequests[index].reason}'),
                Text('Status: ${leaveRequests[index].status.toString()}'),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.thumb_up),
                  onPressed: () {
                    setState(() {
                      leaveRequests[index].status = LeaveStatus.approved;
                    });
                    _saveLeaveRequests();
                  },
                ),
                IconButton(
                  icon: Icon(Icons.thumb_down),
                  onPressed: () {
                    setState(() {
                      leaveRequests[index].status = LeaveStatus.rejected;
                    });
                    _saveLeaveRequests();
                  },
                ),
              ],
            ),
            onTap: () {
              // Handle tap action if needed
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newLeaveRequest = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddLeaveRequestScreen()),
          );
          if (newLeaveRequest != null) {
            setState(() {
              leaveRequests.add(newLeaveRequest);
            });
            _saveLeaveRequests();
          }
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class LeaveRequestsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Leave Requests Screen'),
    );
  }
}

class AddLeaveRequestScreen extends StatelessWidget {
  final TextEditingController _employeeNameController = TextEditingController();
  final TextEditingController _startDateController = TextEditingController();
  final TextEditingController _endDateController = TextEditingController();
  final TextEditingController _reasonController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Leave Request'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _employeeNameController,
              decoration: InputDecoration(labelText: 'Employee Name'),
            ),
            TextField(
              controller: _startDateController,
              decoration: InputDecoration(labelText: 'Start Date'),
              onTap: () async {
                final DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2021),
                  lastDate: DateTime(2025),
                );
                if (picked != null) {
                  _startDateController.text = picked.toString();
                }
              },
            ),
            TextField(
              controller: _endDateController,
              decoration: InputDecoration(labelText: 'End Date'),
              onTap: () async {
                final DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2021),
                  lastDate: DateTime(2025),
                );
                if (picked != null) {
                  _endDateController.text = picked.toString();
                }
              },
            ),
            TextField(
              controller: _reasonController,
              decoration: InputDecoration(labelText: 'Reason'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                String employeeName = _employeeNameController.text;
                DateTime startDate = DateTime.parse(_startDateController.text);
                DateTime endDate = DateTime.parse(_endDateController.text);
                String reason = _reasonController.text;

                final newLeaveRequest = LeaveRequest(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  employeeName: employeeName,
                  startDate: startDate,
                  endDate: endDate,
                  reason: reason,
                  status: LeaveStatus.pending,
                );

                Navigator.pop(context, newLeaveRequest);
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}

class LeaveRequest {
  final String id;
  final String employeeName;
  final DateTime startDate;
  final DateTime endDate;
  final String reason;
  LeaveStatus status;

  LeaveRequest({
    required this.id,
    required this.employeeName,
    required this.startDate,
    required this.endDate,
    required this.reason,
    required this.status,
  });

  factory LeaveRequest.fromJson(Map<String, dynamic> json) {
    return LeaveRequest(
      id: json['id'],
      employeeName: json['employeeName'],
      startDate: DateTime.parse(json['startDate']),
      endDate: DateTime.parse(json['endDate']),
      reason: json['reason'],
      status: LeaveStatus.values[json['status']],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'employeeName': employeeName,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
      'reason': reason,
      'status': status.index,
    };
  }
}

enum LeaveStatus { pending, approved, rejected }
